g++ main.cpp state.cpp k_max_heap.cpp functions.cpp neighbour_id.cpp -o main -pthread -std=c++11
